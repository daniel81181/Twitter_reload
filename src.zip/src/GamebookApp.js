import React from "react";
import { UserContext } from "./hooks/UserContext";
import { MainAppRouter } from "./routers/MainAppRouter";

const username = "userApp"
const password = "lala26"

export const GamebookApp = () => {

    return(
        <>
        <UserContext.Provider value = {
            {
                username,
                password
            }
        }>
            <MainAppRouter/>
        </UserContext.Provider>
        </>
    )
}
